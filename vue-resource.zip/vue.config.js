// vue.config.js
module.exports = {
    // 选项...
    devServer: {
        proxy: 'http://www.kuaidi100.com'
      }
  }