import Vue from 'vue';
import App from './App.vue';
/**
 * 使用vue-resource模块
1. 需要安装vue-resource模块
    npm install vue-resource

2. main.js引入
import VueResource from 'vue-resource';

3. 调用Vue.use(VueResource)

4.在组件里面直接使用

  this.$http.get('/someUrl').then(response => {
 
    
    this.someData = response.body;
 
  }, response => {
    
  });

 */
import VueResource from 'vue-resource';

Vue.use(VueResource)

Vue.config.productionTip = false

new Vue({
  render: h => h(App),
}).$mount('#app')
