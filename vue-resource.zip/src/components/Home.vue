<!--所有的内容要用根节点包含起来-->
<template>
    <div>
        <h2>我是一个Home组件儿~~</h2>
        <br>
        快递名称：<input type="text" v-model="name">
        快递单号：<input type="text" v-model="poid">
        <button @click="getData()">请求数据</button>
        <ul>
            <li v-for="item in list">
                {{item}}
            </li>
        </ul>
    </div> 
</template>

<script>
/*
请求数据模块：
    vue-resource 官方提供的一个vue插件
    
    axios 第三方模块
    
    fetch-jsonp
*/
export default{
    data(){
        return {
            name: "",
            poid: "",
            list:[]
        }
    },
    methods:{
        getData: function(){
            var api="/query?type="+ this.name +"&postid="+this.poid
            
            this.$http.get(api).then(response =>{

                console.log(response);
                this.list = response.body.data;
            }, response =>{

            })
        }
    }
   
}
</script>
<style lang="scss" scoped>
h2{
    color: red
}
</style>