<!--所有的内容要用根节点包含起来-->
<template>
    <div>
        <h2>我是一个Home组件儿~~</h2>
        <v-header :tttitle="title" :method="getData" :home="this" ></v-header>
    </div> 
</template>

<script>
/*
    父组件给子组件传值：
    
    1.父组件调用子组件的时候  绑定动态属性

    2.在子组件里面通过 props接受父组件传过来的数据 
*/
import Header from "./Header.vue";

export default{
    data(){
        return {
            // title:"我是父组件传来的首页"
            title: 11111 //验证合法性：不合法，不为String类型
        }
    },
    components:{
         'v-header': Header
    },
    methods:{
        getData: function(){
            alert(this.title)
        }
    }
}
</script>
<style lang="scss" scoped>
h2{
    color: red
}
</style>