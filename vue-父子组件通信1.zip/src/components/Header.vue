<template>
    <div>
        {{msg}}
        <br>
        {{tttitle}}
        <br>
        <button @click="home.getData()">父组件转来整个实例</button>
        <br>
        <br>
        <button @click="getData()">方法引用父组件的数据</button>
    </div>
</template>
<script>
export default{
    data(){
        return{
            msg: '我是一个Header组件'
        }
    },
    methods:{
        getData: function(){
            alert(this.tttitle)
        }
    },
    props:{
        'tttitle':String,
        'method':Function,
        'home':Object

    }
    
}
</script>