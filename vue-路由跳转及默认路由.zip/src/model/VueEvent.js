 import Vue from 'vue';

 var VueEvent = new Vue();

 export default VueEvent;