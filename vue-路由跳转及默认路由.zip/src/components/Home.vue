<!--所有的内容要用根节点包含起来-->
<template>
    <div>
        <h2>我是一个Home组件儿~~</h2>
        
    </div> 
    
</template>

<script>


export default{
    
}
</script>
<style lang="scss" scoped>
h2{
    color: red
}
</style>