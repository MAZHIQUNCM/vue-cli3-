<!--所有的内容要用根节点包含起来-->
<template>
    <div>
        <h2>我是一个Home组件儿~~</h2>
        <br>
        <button @click="getData()">请求数据</button>
        <ul>
            <li v-for="item in list">
                {{item}}
            </li>
        </ul>
    </div> 
</template>

<script>
/*
axios 的使用（第三方米模块）

1. 安装 npm install axios

2. 哪里用哪里引入axios


*/

import Axios from "axios";

export default{
    data(){
        return {
            list:[]
        }
    },
    methods:{
        getData: function(){
        var api = "/query?type=yuantong&postid=11111111111";
        Axios.get(api)
            .then(response => {
            console.log(response);
            this.list = response.data.data;
             })
            .catch(err => {
                console.log(err);
            })
        }
   
    }
}
</script>
<style lang="scss" scoped>
h2{
    color: red
}
</style>