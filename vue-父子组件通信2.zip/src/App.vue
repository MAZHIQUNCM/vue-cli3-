<template>
  <div id="app">
    <h2>我是一个根组件</h2>
    <v-home></v-home>
 
  </div>
</template>

<script>
/*组件：
  1.引入
  2.挂载
  3.在模板中使用（可以给组件再取个名字）
  
  生命周期函数
  组件挂载以及组件更新组件销毁的时候触发的一系列方法，这些方法叫生命周期函数*/
import Home from './components/Home.vue'


export default {
  name: 'app',
  components: {
    'v-home': Home
   
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
