<template>
    <div>
        <h2>我是一个头部组件</h2>
        <button @click="getData()">点击我获取父组件数据</button>
    </div>
</template>
<script>
export default{
    data(){
        return {
            msg: "头部 头部 头部！！"
        }
    },
    
    methods:{
        getData: function(){
            alert(this.$parent.getData())
        }
    }
    
}
</script>