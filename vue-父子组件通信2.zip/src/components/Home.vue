<!--所有的内容要用根节点包含起来-->
<template>
    <div>
        <h2>我是一个Home组件儿~~</h2>
        
        <v-header ref="header"></v-header>
        <br>
         
        <button @click="getData()">点我获取子组件数据</button>
        <hr>
    </div> 
    
</template>

<script>
/*
  ---- 父组件主动获取子组件数据和方法

1. 父组件调用子组件的时候定义一个ref
    <v-header ref="header"></v-header>
2. 父组件里面通过
    this.$refs.header.属性
    this.$refs.header.方法

  ---- 子组件主动获取父组件数据和方法
        this.$parent.属性    
        this.$parent.方法    
*/
import Header from "./Header.vue";

export default{
    data(){
        return {
        }
    },
    components:{
         'v-header': Header
    },
    methods:{
        getData: function(){
            alert(1)
        }
    }
}
</script>
<style lang="scss" scoped>
h2{
    color: red
}
</style>