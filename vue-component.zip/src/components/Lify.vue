<template>
    <div>
        <h2>生命周期函数/生命周期钩子</h2>
        <p>{{msg}}</p>
        <button @click="change()">点我查看下一句</button>
    </div>
</template>
<script>
 export default{
     data(){
         return {
            msg: "生命就像海洋~~~"
         }
     },
     methods:{
        change: function(){
            this.msg = "只有意志坚强的人才能到达彼岸"
        }
     },
     created(){
         console.log("实例创建完成")
     },
     beforeCreate(){
         console.log("实例创建之前")
     },
     beforeMount(){
         console.log("模板编译之前")
     },
     mounted(){ /*请求数据，操作DOM，放在这个里面   必须记住  mounted*/
         console.log('模板编译完成')
     },
     beforeUpdate(){
         console.log("数据更新完毕")
     },
     updated(){
         console.log("数据更新完毕")
     },
     beforeDestroy(){
         console.log("实例销毁之前")
     },
     destroyed(){
         console.log("实例销毁完成")
     }


 }
</script>