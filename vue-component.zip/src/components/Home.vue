<!--所有的内容要用根节点包含起来-->
<template>
    <div>
        <h2>我是一个Home组件儿~~</h2>
        <Lify v-if="flag"></Lify>
        <br>
        <br>
        <br>
        <button @click="flag = !flag">挂载以及卸载lify组件</button>
    
    </div> 
</template>

<script>
import Lify from './Lify.vue';
export default{
    data(){
        return {
            flag: true
        }
    },
    components: {
        Lify
    }
}
</script>
<style lang="scss" scoped>
h2{
    color: red
}
</style>