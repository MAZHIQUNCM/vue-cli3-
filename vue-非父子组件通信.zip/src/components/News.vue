<template>
    <div>
        <h2>我是新闻组件</h2>
        <br>
        <button @click="emitData()">开启news广播</button>
        <input v-model="msg1">
        <br>
        <br>
        
    </div>
</template>
<script>
import VueEvent from '../model/VueEvent.js';
    export default{
        data(){
            return{
                msg1: "我是news的广播"
            }
        },
        methods:{
            emitData: function(){
                VueEvent.$emit('to-home', this.msg1)
            }
        },
       mounted(){
           /*
           此处注意this的指向,一下实现不了数据的双向绑定
                    VueEvent.$on('to-news',function(data) {
                    this.msg1 = data; 
                })
           */
           
           VueEvent.$on('to-news',data => {
               this.msg1 = data
           })
       }
    }
</script>
<style lang="scss">


</style>