<!--所有的内容要用根节点包含起来-->
<template>
    <div>
        <h2>我是一个Home组件儿~~</h2>
        <button @click="emitData()">开启home广播~</button>
        <input v-model="msg">
        <br>
        <hr>
    </div> 
    
</template>

<script>
import VueEvent from '../model/VueEvent.js';

export default{
    data(){
        return {
            msg: "我是home组件广播的消息"
        }
    },
    components:{
        
    },
    methods:{
       emitData: function(){
           VueEvent.$emit('to-news', this.msg)
       }

    },
    mounted(){
        VueEvent.$on('to-home', data => {
            this.msg = data
        })
    }
}
</script>
<style lang="scss" scoped>
h2{
    color: red
}
</style>