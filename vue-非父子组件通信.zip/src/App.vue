<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png">
    <h2>我是一个根组件</h2>
    <v-home></v-home>
    <v-news></v-news>
  </div>
</template>

<script>
/*
    非父子组件传值：
 
  1. 新建一个js文件   然后引入vue 实例化vue 最后暴露这个实例

  2. 在要广播的地方引入刚才定义的实例

  3. 通过VueEmit.$emit('名称','数据')

  4. 在接收数据的地方通过 $on 接收广播的数据
      VueEmit.$on('名称', function(){

      })

  */
import Home from './components/Home.vue'
import News from './components/News.vue'


export default {
  name: 'app',
  components: {
    'v-home': Home,
    'v-news': News
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
